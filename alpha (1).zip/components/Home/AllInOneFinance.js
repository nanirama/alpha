export default function AllInOneFinance() {
  return (
    <h1 className="text-3xl font-bold underline p-5 m-5 text-gray-300 tracking-wider">
      This is All In One Finance Section
    </h1>
  )
}
