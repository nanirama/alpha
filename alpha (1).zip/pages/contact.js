import Layout from "../components/layout";

import ContactComponent from "../components/Contact/Contact_Component";

export default function Home() {
	return (
		<Layout>
			<ContactComponent />
		</Layout>
	);
}
