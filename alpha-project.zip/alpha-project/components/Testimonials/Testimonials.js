export default function Testimonial() {
	return (
		<div>
			<h2>Testimonials section</h2>
		</div>
	);
}
