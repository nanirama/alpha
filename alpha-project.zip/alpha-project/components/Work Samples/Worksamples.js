export default function WorkSamples() {
    return (
        <div>
            <h2>Work samples section</h2>
        </div>
    );
}