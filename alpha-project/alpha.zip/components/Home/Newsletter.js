export default function Newsletter() {
  return (
    <h1 className="text-3xl font-bold underline p-5 m-5 text-gray-300 tracking-wider">
      This is Newsletter Section
    </h1>
  )
}
